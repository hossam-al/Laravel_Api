

<?php $__env->startSection('content'); ?>
<h2 style="margin-top:0;">إضافة علامة</h2>
<form method="post" action="<?php echo e(route('web.brands.store')); ?>" class="row">
    <?php echo csrf_field(); ?>
    <label>الاسم
        <input type="text" name="name" value="<?php echo e(old('name')); ?>" required>
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </label>
    <label>الوصف
        <input type="text" name="description" value="<?php echo e(old('description')); ?>">
    </label>
    <label style="display:flex; align-items:center; gap:8px;">
        <input type="checkbox" name="is_active" value="1" checked style="width:auto;"> نشط
    </label>
    <button type="submit">حفظ</button>
</form>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\hossa\Desktop\LARAVEL-API\Laravel-api\resources\views/web/brands/create.blade.php ENDPATH**/ ?>