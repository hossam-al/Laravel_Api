<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>Document</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

</head>

<body>
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <img src="" alt="">
                    <div class="catd-body">
                        <h2>Lorem, ipsum.</h2>
                        <p>Lorem ipsum dolor sit amet.</p>

                    </div>
                </div>
            </div>
        </div>
    </section>
</body>

</html>
<?php /**PATH C:\Users\hossa\Desktop\LARAVEL-API\Laravel-api\resources\views/welcome.blade.php ENDPATH**/ ?>