

<?php $__env->startSection('content'); ?>
<div style="display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap;">
    <h2 style="margin:0;">الأقسام</h2>
    <a href="<?php echo e(route('web.categories.create')); ?>" class="btn" style="background:#2563eb;color:#fff;padding:10px 14px;border-radius:8px;">+ إضافة قسم</a>
    <?php if(session('ok')): ?>
    <div style="background:#ecfdf5;color:#065f46;padding:8px 12px;border-radius:8px;"><?php echo e(session('ok')); ?></div>
    <?php endif; ?>
</div>

<table style="width:100%;border-collapse:collapse;margin-top:12px;">
    <thead>
        <tr>
            <th style="text-align:right;padding:8px;border-bottom:1px solid #eee;">#</th>
            <th style="text-align:right;padding:8px;border-bottom:1px solid #eee;">الاسم</th>
            <th style="text-align:right;padding:8px;border-bottom:1px solid #eee;">Slug</th>
            <th style="text-align:right;padding:8px;border-bottom:1px solid #eee;">نشط؟</th>
            <th style="text-align:right;padding:8px;border-bottom:1px solid #eee;">إجراءات</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td style="padding:8px;border-bottom:1px solid #f3f4f6;"><?php echo e($c->id); ?></td>
            <td style="padding:8px;border-bottom:1px solid #f3f4f6;"><?php echo e($c->name); ?></td>
            <td style="padding:8px;border-bottom:1px solid #f3f4f6;"><?php echo e($c->slug); ?></td>
            <td style="padding:8px;border-bottom:1px solid #f3f4f6;"><?php echo e($c->is_active ? 'نعم' : 'لا'); ?></td>
            <td style="padding:8px;border-bottom:1px solid #f3f4f6;display:flex;gap:8px;">
                <a href="<?php echo e(route('web.categories.edit', $c)); ?>">تعديل</a>
                <form action="<?php echo e(route('web.categories.destroy', $c)); ?>" method="post" onsubmit="return confirm('حذف القسم؟');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" style="background:#b91c1c; color:#fff; padding:6px 10px; border-radius:6px;">حذف</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="5" style="padding:12px;">لا توجد أقسام.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<div style="margin-top:12px;">
    <?php echo e($categories->links()); ?>

    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\hossa\Desktop\LARAVEL-API\Laravel-api\resources\views/web/categories/index.blade.php ENDPATH**/ ?>