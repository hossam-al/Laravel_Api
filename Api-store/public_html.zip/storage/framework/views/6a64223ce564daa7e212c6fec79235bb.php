<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة التحكم - API</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>

    </style>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" href="/favicon.ico">
    <meta name="robots" content="noindex">
    <meta name="turbolinks-cache-control" content="no-cache">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <meta name="color-scheme" content="light dark">
    <meta name="theme-color" content="#111827">
    <meta name="description" content="لوحة تحكم بسيطة لإدارة API ومتابعة الإحصائيات الأساسية.">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="<?php echo e(asset('assets/css/dashboard.css')); ?>" rel="stylesheet">

    <script defer src="<?php echo e(asset('assets/js/dashboard.js')); ?>"></script>


</head>

<body>
    <div class="container">
        <header>
            <div>
                <h1>لوحة التحكم</h1>
                <span>إحصائيات سريعة للنظام</span>
            </div>
            <div class="dropdown">
                <button class="dropdown-btn" id="profileToggle">
                    <span class="avatar"><?php echo e(strtoupper(mb_substr(auth()->user()->name, 0, 1))); ?></span>
                    <span><?php echo e(auth()->user()->name); ?></span>
                    <i class="chev"></i>
                </button>
                <div class="menu" id="profileMenu">
                    <div class="hdr">
                        <div class="name"><?php echo e(auth()->user()->name); ?></div>
                        <div class="email"><?php echo e(auth()->user()->email); ?></div>
                    </div>
                    <div class="item">
                        <a href="<?php echo e(route('profile')); ?>">فتح الملف الشخصي</a>
                    </div>
                    <div class="item">
                        <form method="post" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" style="width:100%;">تسجيل الخروج</button>
                        </form>
                    </div>
                </div>
            </div>
        </header>


        <nav>
            <a href="<?php echo e(route('admin.dashboard')); ?>">الرئيسية</a>
            <a href="/products">المنتجات</a>
        </nav>
        <form method="get" action="<?php echo e(route('admin.dashboard')); ?>" style="margin-bottom:16px;">
            <label>المدى الزمني:
                <select name="range" onchange="this.form.submit()">
                    <option value="24h" <?php echo e(($cartMetrics['range'] ?? '') === '24h' ? 'selected' : ''); ?>>آخر 24 ساعة
                    </option>
                    <option value="7d" <?php echo e(($cartMetrics['range'] ?? '') === '7d' ? 'selected' : ''); ?>>آخر 7 أيام
                    </option>
                    <option value="30d" <?php echo e(($cartMetrics['range'] ?? '') === '30d' ? 'selected' : ''); ?>>آخر 30 يوماً
                    </option>
                    <option value="all" <?php echo e(($cartMetrics['range'] ?? '') === 'all' ? 'selected' : ''); ?>>الكل
                    </option>
                </select>
            </label>
        </form>

        <section class="grid">
            <div class="card">
                <div class="label">المستخدمون</div>
                <div class="value"><?php echo e(number_format($metrics['users'])); ?></div>
            </div>
            <div class="card">
                <div class="label">المنتجات</div>
                <div class="value"><?php echo e(number_format($metrics['products'])); ?></div>
            </div>
            <div class="card">
                <div class="label">الطلبات</div>
                <div class="value"><?php echo e(number_format($metrics['orders'])); ?></div>
            </div>
            <div class="card">
                <div class="label">الأقسام</div>
                <div class="value"><?php echo e(number_format($metrics['categories'])); ?></div>
            </div>
            <div class="card">
                <div class="label">العلامات التجارية</div>
                <div class="value"><?php echo e(number_format($metrics['brands'])); ?></div>
            </div>
        </section>

        <section class="grid" style="margin-top:12px;">
            <div class="card">
                <div class="label">السلال</div>
                <div class="value"><?php echo e(number_format($cartMetrics['carts'])); ?></div>
            </div>
            <div class="card">
                <div class="label">عناصر السلال</div>
                <div class="value"><?php echo e(number_format($cartMetrics['cart_items'])); ?></div>
            </div>
            <div class="card">
                <div class="label">قائمة الرغبات</div>
                <div class="value"><?php echo e(number_format($cartMetrics['wishlists'])); ?></div>
            </div>
            <div class="card">
                <div class="label">الإيرادات (المدى المحدد)</div>
                <div class="value"><?php echo e(number_format($cartMetrics['revenue'], 2)); ?></div>
            </div>
            <div class="card">
                <div class="label">متوسط قيمة الطلب</div>
                <div class="value"><?php echo e(number_format($cartMetrics['avg_order_value'], 2)); ?></div>
            </div>
        </section>

        <h2 class="section-title">أكثر المسارات استخداماً</h2>
        <table>
            <thead>
                <tr>
                    <th>الطريقة</th>
                    <th>المسار</th>
                    <th>عدد الطلبات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $topEndpoints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($row->method); ?></td>
                        <td><?php echo e($row->path); ?></td>
                        <td><?php echo e(number_format($row->hits)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="3">لا توجد بيانات بعد.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <h2 class="section-title">أحدث 20 طلب</h2>
        <table>
            <thead>
                <tr>
                    <th>الوقت</th>
                    <th>الطريقة</th>
                    <th>المسار</th>
                    <th>الحالة</th>
                    <th>IP</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $recentLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($log->created_at->format('Y-m-d H:i:s')); ?></td>
                        <td><?php echo e($log->method); ?></td>
                        <td><?php echo e($log->path); ?></td>
                        <td><?php echo e($log->status_code); ?></td>
                        <td><?php echo e($log->ip); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5">لا توجد بيانات بعد.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="cols">
            <div>
                <h2 class="section-title">أحدث الطلبات</h2>
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>المستخدم</th>
                            <th>الحالة</th>
                            <th>العناصر</th>
                            <th>الإجمالي</th>
                            <th>التاريخ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $recentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($o->id); ?></td>
                                <td><?php echo e(optional($o->user)->name ?? '-'); ?></td>
                                <td><?php echo e($o->status); ?></td>
                                <td><?php echo e($o->items_count); ?></td>
                                <td><?php echo e(number_format($o->total_price, 2)); ?></td>
                                <td><?php echo e($o->created_at->format('Y-m-d H:i')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6">لا توجد طلبات.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div>
                <h2 class="section-title">توزيع الحالات</h2>
                <table>
                    <thead>
                        <tr>
                            <th>الحالة</th>
                            <th>عدد الطلبات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $orderStatusBreakdown; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($row->status); ?></td>
                                <td><?php echo e(number_format($row->count)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="2">لا توجد بيانات.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="cols">
            <div>
                <h2 class="section-title">أكثر المنتجات إضافة للسلة</h2>
                <table>
                    <thead>
                        <tr>
                            <th>المنتج</th>
                            <th>مرات الإضافة</th>
                            <th>الكمية الإجمالية</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $topCartProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>#<?php echo e($p->product_id); ?></td>
                                <td><?php echo e(number_format($p->times)); ?></td>
                                <td><?php echo e(number_format($p->qty)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="3">لا توجد بيانات.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div>
                <h2 class="section-title">أكثر المنتجات في المفضلة</h2>
                <table>
                    <thead>
                        <tr>
                            <th>المنتج</th>
                            <th>مرات الإضافة</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $topWishlistProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>#<?php echo e($p->product_id); ?></td>
                                <td><?php echo e(number_format($p->times)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="2">لا توجد بيانات.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="footer">© <?php echo e(date('Y')); ?> لوحة تحكم بسيطة - Laravel API</div>
    </div>
</body>

</html>
<?php /**PATH C:\Users\hossa\Desktop\LARAVEL-API\Laravel-api\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>