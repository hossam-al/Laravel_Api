

<?php $__env->startSection('content'); ?>
<div style="display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap;">
    <h2 style="margin:0;">المنتجات</h2>
    <a href="<?php echo e(route('web.products.create')); ?>" class="btn" style="background:#2563eb;color:#fff;padding:10px 14px;border-radius:8px;">+ إضافة منتج</a>
    <?php if(session('ok')): ?>
    <div style="background:#ecfdf5;color:#065f46;padding:8px 12px;border-radius:8px;"><?php echo e(session('ok')); ?></div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
    <div style="background:#fef2f2;color:#991b1b;padding:8px 12px;border-radius:8px;"><?php echo e($errors->first()); ?></div>
    <?php endif; ?>
</div>

<table style="width:100%;border-collapse:collapse;margin-top:12px;">
    <thead>
        <tr>
            <th style="text-align:right;padding:8px;border-bottom:1px solid #eee;">#</th>
            <th style="text-align:right;padding:8px;border-bottom:1px solid #eee;">الاسم</th>
            <th style="text-align:right;padding:8px;border-bottom:1px solid #eee;">السعر</th>
            <th style="text-align:right;padding:8px;border-bottom:1px solid #eee;">المخزون</th>
            <th style="text-align:right;padding:8px;border-bottom:1px solid #eee;">القسم</th>
            <th style="text-align:right;padding:8px;border-bottom:1px solid #eee;">العلامة</th>
            <th style="text-align:right;padding:8px;border-bottom:1px solid #eee;">نشط؟</th>
            <th style="text-align:right;padding:8px;border-bottom:1px solid #eee;">إجراءات</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td style="padding:8px;border-bottom:1px solid #f3f4f6;"><?php echo e($p->id); ?></td>
            <td style="padding:8px;border-bottom:1px solid #f3f4f6;"><?php echo e($p->name); ?></td>
            <td style="padding:8px;border-bottom:1px solid #f3f4f6;"><?php echo e(number_format($p->price, 2)); ?></td>
            <td style="padding:8px;border-bottom:1px solid #f3f4f6;"><?php echo e($p->stock); ?></td>
            <td style="padding:8px;border-bottom:1px solid #f3f4f6;"><?php echo e(optional($p->Category)->name ?? '-'); ?></td>
            <td style="padding:8px;border-bottom:1px solid #f3f4f6;"><?php echo e(optional($p->brand)->name ?? '-'); ?></td>
            <td style="padding:8px;border-bottom:1px solid #f3f4f6;"><?php echo e($p->is_active ? 'نعم' : 'لا'); ?></td>
            <td style="padding:8px;border-bottom:1px solid #f3f4f6;display:flex;gap:8px;">
                <a href="<?php echo e(route('web.products.edit', $p)); ?>">تعديل</a>
                <form action="<?php echo e(route('web.products.destroy', $p)); ?>" method="post" onsubmit="return confirm('حذف المنتج؟');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" style="background:#b91c1c; color:#fff; padding:6px 10px; border-radius:6px;">حذف</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="8" style="padding:12px;">لا توجد منتجات.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<div style="margin-top:12px;">
    <?php echo e($products->links()); ?>

    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\hossa\Desktop\LARAVEL-API\Laravel-api\resources\views/web/products/index.blade.php ENDPATH**/ ?>