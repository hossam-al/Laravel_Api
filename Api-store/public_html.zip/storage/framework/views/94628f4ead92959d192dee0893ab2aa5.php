<?php $__env->startSection('content'); ?>
<h2 >الملف الشخصي</h2>
<div class="row">
    <label>الاسم
        <input type="text" value="<?php echo e($user->name); ?>" disabled>
    </label>
    <label>البريد الإلكتروني
        <input type="text" value="<?php echo e($user->email); ?>" disabled>
    </label>
    <?php if($user->phone): ?>
    <label>الهاتف
        <input type="text" value="<?php echo e($user->phone); ?>" disabled>
    </label>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u760370294/domains/makharita.store/public_html/resources/views/profile.blade.php ENDPATH**/ ?>