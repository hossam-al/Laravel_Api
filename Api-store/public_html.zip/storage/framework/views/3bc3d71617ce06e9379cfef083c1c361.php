<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title ?? 'لوحة الويب'); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700&display=swap" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/app.css')); ?>" rel="stylesheet">
    <style>

    </style>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>
    <div class="container">
        <header>
            <div>
                <a href="/">الرئيسية</a>
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('web.products.index')); ?>" class="nav-link" style="margin-inline-start:12px;">المنتجات (Web)</a>
                    <a href="<?php echo e(route('web.categories.index')); ?>" class="nav-link" style="margin-inline-start:12px;">الأقسام (Web)</a>
                    <a href="<?php echo e(route('web.brands.index')); ?>" class="nav-link" style="margin-inline-start:12px;">العلامات (Web)</a>
                <?php endif; ?>
            </div>
            <nav class="nav">
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('profile')); ?>">الملف الشخصي</a>
                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">تسجيل الخروج</a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="post" style="display:none;">
                        <?php echo csrf_field(); ?>
                    </form>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>">تسجيل الدخول</a>
                    <a href="<?php echo e(route('register')); ?>">إنشاء حساب</a>
                <?php endif; ?>
            </nav>
        </header>
        <div class="card">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
</body>
</html>


<?php /**PATH C:\Users\hossa\Desktop\LARAVEL-API\Laravel-api\resources\views/layouts/app.blade.php ENDPATH**/ ?>